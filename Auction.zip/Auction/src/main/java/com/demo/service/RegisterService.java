package com.demo.service;
import com.demo.beans.Product;
import com.demo.beans.User;

public interface RegisterService
{
	void addUser(User u);
}
