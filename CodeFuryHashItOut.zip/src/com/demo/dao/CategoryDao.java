package com.demo.dao;

public interface CategoryDao {
  int selectId(String name);
}
