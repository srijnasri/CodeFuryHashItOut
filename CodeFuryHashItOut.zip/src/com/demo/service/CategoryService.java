package com.demo.service;

public interface CategoryService {
   int selectCategory(String name);
}
