package com.demo.service;
import com.demo.beans.User;

public interface LoginService
{
	int validateUser(String uname, String pass);
}
