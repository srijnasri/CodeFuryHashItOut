package com.demo.dao;

import com.demo.beans.User;

public interface RegisterDao 
{

	void addUserdb(User u);

}
